-- Activity Center Database - DB Design Project

CREATE TABLE Equipment
(
EquipmentID int primary key,
EquipmentAvailabilityStatus varchar2(5) 
);

CREATE TABLE GymEquipmentType
(
GymEquipmentTypeID int primary key,
Description varchar2(10)
);

CREATE TABLE GymEquipment
(
GymEquipmentID int primary key,
LastService date,
NextService date,
GymEquipmentTypeID int,
Foreign Key (GymEquipmentID) References Equipment(EquipmentID) on delete cascade,
Foreign Key (GymEquipmentTypeID) References GymEquipmentType(GymEquipmentTypeID) on delete set null
);

CREATE TABLE ItemCategory
(
ItemCategoryID int primary key,
ItemCategoryName varchar2(20)
);

CREATE TABLE SportsCategory
(
SportsCategoryID int primary key,
SportsName varchar2(10)
);  

CREATE TABLE SportsEquipment
(
SportsEquipmentID int primary key,
ItemCategoryID int,
SportsCategoryID int,
Foreign Key (SportsEquipmentID) references Equipment(EquipmentID) on delete cascade,
Foreign Key (ItemCategoryID) references ItemCategory(ItemCategoryID) on delete set null,
Foreign Key (SportsCategoryID) references SportsCategory(SportsCategoryID) on delete set null
);

CREATE TABLE PlayCourt
(
CourtID int primary key,
CourtAvailabilityStatus varchar2(5),
SportsCategoryID int,
Foreign Key (SportsCategoryID) references SportsCategory(SportsCategoryID) on delete set null
);

CREATE TABLE UserDetails
(
UserID int primary key,
UserName varchar2(30),
AptNo int,
StreetName varchar2(20),
City varchar2(10),
State varchar2(10),
ZIP number(5),
Mobile_No int
);

CREATE TABLE Fee
(
FeeID int primary key,
FeeName varchar2(20),
SubscriptionPeriod varchar2(10),
Amount int
);

CREATE TABLE Guest
(
GuestUserID int primary key,
FeeID int,
Foreign Key (GuestUserID) references UserDetails(UserID) on delete cascade,
Foreign Key (FeeID) references Fee(FeeID) on delete set null
); 

CREATE TABLE Student
(
StudentUserID int primary key,
Foreign Key (StudentUserID) references UserDetails(UserID) on delete cascade
);

CREATE TABLE Employee1
(
EmployeeUserID int primary key,
Foreign Key (EmployeeUserID) references UserDetails(UserID) on delete cascade
);

CREATE TABLE StudentWorker
(
StudentWorkerID int primary key,
TotalWorkHours int,
Salary int,
Foreign Key (StudentWorkerID) references UserDetails(UserID) on delete cascade
);

CREATE TABLE LockerModel
(
LockerSize varchar2(5) primary key,
Rent int
);

CREATE TABLE Locker
(
LockerID int primary key,
LocketType varchar2(20),
LockerSize varchar2(5),
Foreign Key (LockerSize) references LockerModel(LockerSize) on delete set null
);

CREATE TABLE UserLocker
(
LockerID int,
UserID int,
StartTimeStamp timestamp,
EndTimeStamp timestamp,
PRIMARY KEY (LockerID, StartTimeStamp),
Foreign Key (LockerID) references Locker(LockerID) on delete cascade,
Foreign Key (UserID) references UserDetails(UserID) on delete set null
);

CREATE TABLE Borrow
(
SportsEquipmentID int,
UserID int,
BorrowID int primary key,
BorrowDate timestamp,
DueDate timestamp,
ReturnDate timestamp,
StudentWorkerID int,
Foreign Key (SportsEquipmentID) references SportsEquipment(SportsEquipmentID) on delete cascade,
Foreign Key (UserID) references UserDetails(UserID) on delete set null,
Foreign Key (StudentWorkerID) references StudentWorker(StudentWorkerID) on delete set null
);

CREATE TABLE Booking
(
UserID int,
BookingID int primary key,
BookedDate timestamp,
StartTimeStamp timestamp,
DueTimeStamp timestamp,
ReturnDate timestamp,
StudentWorkerID int,
CourtID int,
Foreign Key (UserID) references UserDetails(UserID) on delete set null,
Foreign Key (StudentWorkerID) references StudentWorker(StudentWorkerID) on delete set null,
Foreign Key (CourtID) references PlayCourt(CourtID) on delete cascade
);

-- Data Population

INSERT INTO Equipment values (&EquipmentID, '&EquipmentAvailabilityStatus');

INSERT INTO GymEquipmentType values (&GymEquipmentTypeID , '&Description');

INSERT INTO GymEquipment values (&GymEquipmentID, '&LastService', '&NextService', &GymEquipmentTypeID);

INSERT INTO ItemCategory values (&ItemCategoryID, '&ItemCategoryName');

INSERT INTO SportsCategory values (&SportsCategoryID, '&SportsCategoryName');

INSERT INTO SportsEquipment values (&SportsEquipmentID, &ItemCategoryID, &SportsCategoryID);

INSERT INTO PlayCourt values (&CourtID, '&CourtAvailabilityStaus', &SportsCategoryID);

INSERT INTO UserDetails values (&UserID, '&UserName', &AptNo, '&StreetName', '&City', '&State', &ZIP, &Mobile_No);

INSERT INTO Fee Values (&FeeID, '&FeeName', '&SubscriptionPeriod', &Amount);

INSERT INTO Guest values (&GuestUserID, &FeeID);

INSERT INTO Student values (&StudentUserID);

INSERT INTO Employee1 values (&EmployeeUserID);

INSERT INTO StudentWorker values (&StudentWorkerID, &TotalWorkHours, &Salary);

INSERT INTO LockerModel values ('&LockerSize', &Rent);

INSERT INTO Locker values (&LockerID, '&LockerType', '&LockerSize');

INSERT INTO UserLocker values (&LockerID, &UserID, '&StartTimeStamp', '&EndTimeStamp');

INSERT INTO Borrow values (&SportsEquipmentID, &UserID, &BorrowID, '&BorrowDate', '&DueDate', '&ReturnDate', &StudentWorkerID);

INSERT INTO Booking values (&UserID, &BookingID, '&BookedDate', '&StartTimeStamp', '&DueTimeStamp', '&ReturnDate', &StudentWorkerID, &CourtID);